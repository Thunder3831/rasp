#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import time
import sys
import re

# ----- تنظیمات ورودی -----
hid_path = "/dev/hidg0"
mail = sys.argv[1]
password = sys.argv[2]

# اگر آرگومان سوم "n" باشد یعنی @ را با " جایگزین کن (بعضی UIها @ را نمی‌پذیرند)
replace_at_arg = sys.argv[3] if len(sys.argv) > 3 else "@"
delay_factor = float(sys.argv[4]) / 10 if len(sys.argv) > 4 else 1.0

replace_at = '"' if replace_at_arg == "n" else replace_at_arg
mail = mail.replace('@', replace_at)
password = password.replace('@', replace_at)

# ----- نقشه‌ی کدهای کلید (US layout) -----
key_codes = {
    "esc": 0x29, "enter": 0x28, "left": 0x50, "right": 0x4F,
    "down": 0x51, "up": 0x52, "backspace": 0x2A, "tab": 0x2B,
    "space": 0x2C,
}

# ----- توابع کمکی -----
def press_key(hid_file, key_code, shift=False, hold_time=0.05):
    """
    دکمه را فشار می‌دهد، به مدت hold_time پایین نگه می‌دارد، سپس رها می‌کند.
    """
    modifiers = 0x02 if shift else 0x00  # بیت شیفت
    report = bytearray(8)
    report[0] = modifiers     # modifiers
    report[2] = key_code      # keycode
    hid_file.write(report)
    hid_file.flush()
    time.sleep(hold_time)
    hid_file.write(bytearray(8))  # رها کردن کلید
    hid_file.flush()
    time.sleep(0.01)

def press_key_repeat(hid_file, key_code, times, gap=0.03):
    """
    یک کلید را times بار پشت‌سرهم فشار می‌دهد (برای وقتی که auto-repeat سیستم خاموش است).
    """
    for _ in range(times):
        press_key(hid_file, key_code, shift=False, hold_time=0.02 * delay_factor)
        time.sleep(gap * delay_factor)

def char_to_keycode(ch):
    char_map = {
        'a': (0x04, False), 'b': (0x05, False), 'c': (0x06, False), 'd': (0x07, False),
        'e': (0x08, False), 'f': (0x09, False), 'g': (0x0A, False), 'h': (0x0B, False),
        'i': (0x0C, False), 'j': (0x0D, False), 'k': (0x0E, False), 'l': (0x0F, False),
        'm': (0x10, False), 'n': (0x11, False), 'o': (0x12, False), 'p': (0x13, False),
        'q': (0x14, False), 'r': (0x15, False), 's': (0x16, False), 't': (0x17, False),
        'u': (0x18, False), 'v': (0x19, False), 'w': (0x1A, False), 'x': (0x1B, False),
        'y': (0x1C, False), 'z': (0x1D, False),
        'A': (0x04, True),  'B': (0x05, True),  'C': (0x06, True),  'D': (0x07, True),
        'E': (0x08, True),  'F': (0x09, True),  'G': (0x0A, True),  'H': (0x0B, True),
        'I': (0x0C, True),  'J': (0x0D, True),  'K': (0x0E, True),  'L': (0x0F, True),
        'M': (0x10, True),  'N': (0x11, True),  'O': (0x12, True),  'P': (0x13, True),
        'Q': (0x14, True),  'R': (0x15, True),  'S': (0x16, True),  'T': (0x17, True),
        'U': (0x18, True),  'V': (0x19, True),  'W': (0x1A, True),  'X': (0x1B, True),
        'Y': (0x1C, True),  'Z': (0x1D, True),
        '1': (0x1E, False), '2': (0x1F, False), '3': (0x20, False), '4': (0x21, False),
        '5': (0x22, False), '6': (0x23, False), '7': (0x24, False), '8': (0x25, False),
        '9': (0x26, False), '0': (0x27, False),
        '!': (0x1E, True),  '@': (0x1F, True),  '#': (0x20, True),  '$': (0x21, True),
        '%': (0x22, True),  '^': (0x23, True),  '&': (0x24, True),  '*': (0x25, True),
        '(': (0x26, True),  ')': (0x27, True),
        '-': (0x2D, False), '_': (0x2D, True),  '=': (0x2E, False), '+': (0x2E, True),
        '[': (0x2F, False), '{': (0x2F, True),  ']': (0x30, False), '}': (0x30, True),
        '\\':(0x31, False), '|': (0x31, True),  ';': (0x33, False), ':': (0x33, True),
        '\'':(0x34, False), '"': (0x34, True),  '`': (0x35, False), '~': (0x35, True),
        ',': (0x36, False), '<': (0x36, True),  '.': (0x37, False), '>': (0x37, True),
        '/': (0x38, False), '?': (0x38, True),  ' ': (0x2C, False),
    }
    return char_map.get(ch, (0x2C, False))  # پیش‌فرض space

def type_string(hid_file, s):
    for ch in s:
        key_code, shift = char_to_keycode(ch)
        press_key(hid_file, key_code, shift)
        time.sleep(0.05 * delay_factor)

# ----- DSL دستورات -----
# پشتیبانی: عددِ خالی (تاخیر ms)، کلید ساده ("down" و ...)،
# "mail" و "pass"،
# "<key> hold <ms>"، "<key> repeat <n>"، "sleep <ms>"
sequence = [
	"enter", 500,
	"backspace hold  3000",
        "mail",
        "enter", 200,
	"up" , 300
]

# الگوها
re_hold   = re.compile(r'^\s*([A-Za-z]+)\s+hold\s+(\d+)\s*$')
re_repeat = re.compile(r'^\s*([A-Za-z]+)\s+repeat\s+(\d+)\s*$')
re_sleep  = re.compile(r'^\s*sleep\s+(\d+)\s*$')

def main():
    with open(hid_path, "wb") as hid_file:
        for cmd in sequence:
            # 1) تاخیر عددی خالی (ms)
            if isinstance(cmd, int):
                time.sleep((cmd * delay_factor) / 1000.0)
                continue

            if not isinstance(cmd, str):
                print("Unknown command type:", type(cmd))
                continue

            s = cmd.strip()

            # 2) دستورات متنی ویژه
            if s == "mail":
                type_string(hid_file, mail)
                continue
            if s == "pass":
                type_string(hid_file, password)
                continue

            # 3) sleep <ms>
            m = re_sleep.fullmatch(s)
            if m:
                ms = int(m.group(1))
                time.sleep((ms * delay_factor) / 1000.0)
                continue

            # 4) <key> hold <ms>
            m = re_hold.fullmatch(s)
            if m:
                key_name, ms = m.groups()
                key_name = key_name.lower()
                if key_name in key_codes:
                    hold_s = (int(ms) * delay_factor) / 1000.0
                    press_key(hid_file, key_codes[key_name], hold_time=hold_s)
                else:
                    print("Unknown key in hold:", key_name)
                continue

            # 5) <key> repeat <n>
            m = re_repeat.fullmatch(s)
            if m:
                key_name, n = m.groups()
                key_name = key_name.lower()
                if key_name in key_codes:
                    press_key_repeat(hid_file, key_codes[key_name], int(n))
                else:
                    print("Unknown key in repeat:", key_name)
                continue

            # 6) کلیدهای ساده
            key_name = s.lower()
            if key_name in key_codes:
                press_key(hid_file, key_codes[key_name])
                continue

            # 7) ناشناخته
            print("Unknown command:", cmd)

if __name__ == "__main__":
    main()
