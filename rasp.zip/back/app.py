from flask import Flask, render_template, request, redirect, url_for, jsonify, Response
import threading
import subprocess
import os

app = Flask(__name__)

CREDENTIALS_FILE = "credentials.txt"
CURRENT_INDEX_FILE = "current_index.txt"
REPLACE_AT_FILE = "replace_at.txt"
STATUS_FILE = "status.txt"
SPEED_FILE = "speed.txt"
TOTP_FILE = "totp_code.txt"

def write_status(status: str):
    with open(STATUS_FILE, "w") as f:
        f.write(status)

def run_hid_script(program_number: int, advance: bool = True):
    try:
        try:
            with open(REPLACE_AT_FILE, "r") as f:
                replace_at = f.read().strip()
        except:
            replace_at = "@"

        try:
            with open(SPEED_FILE, "r") as f:
                speed_delay = f.read().strip()
        except:
            speed_delay = "10"

        try:
            with open(CURRENT_INDEX_FILE, "r") as f:
                index = int(f.read().strip())
        except:
            index = 0

        try:
            with open(CREDENTIALS_FILE, "r") as f:
                lines = [line.strip() for line in f if line.strip()]
        except:
            lines = []

        mail = ""
        password = ""
        if index < len(lines):
            creds = lines[index]
            # اگر خط دارای ":" نیست مشکلی نیست؛ آرگومان‌ها خالی می‌مانند
            if ":" in creds:
                mail, password = creds.split(":", 1)
            else:
                mail = creds
                password = ""
            if advance:
                with open(CURRENT_INDEX_FILE, "w") as f:
                    f.write(str(index + 1))
        else:
            if program_number != 20:
                return

        write_status("won")

        script_name = f"hid_program{program_number}.py"
        subprocess.run(["python3", script_name, mail, password, replace_at, str(speed_delay)])
    finally:
        write_status("woff")

@app.route('/')
def index():
    try:
        with open(CURRENT_INDEX_FILE, "r") as f:
            index = int(f.read().strip())
    except:
        index = 0

    try:
        with open(CREDENTIALS_FILE, "r") as f:
            lines = [line.strip() for line in f if line.strip()]
    except:
        lines = []

    total = len(lines)
    current = lines[index] if index < total else "END"
    previous = "NONE" if total == 0 or index == 0 else lines[index - 1]

    try:
        with open(REPLACE_AT_FILE, "r") as f:
            replace_at = f.read().strip()
    except:
        replace_at = "@"

    try:
        with open(SPEED_FILE, "r") as f:
            speed = int(f.read().strip())
    except:
        speed = 10

    return render_template(
        "index.html",
        current=current,
        previous=previous,
        index=index + 1,   # برای نمایش (۱-مبنایی)
        total=total,
        replace_at=replace_at,
        speed=speed
    )

@app.route('/update', methods=['POST'])
def update():
    data = request.form['data']
    with open(CREDENTIALS_FILE, "w") as f:
        f.write(data)
    with open(CURRENT_INDEX_FILE, "w") as f:
        f.write("0")
    return redirect("/")

@app.route('/CharFixA')
def char_fix_a():
    with open(REPLACE_AT_FILE, "w") as f:
        f.write("@")
    return redirect("/")

@app.route('/CharFixN')
def char_fix_n():
    with open(REPLACE_AT_FILE, "w") as f:
        f.write("n")
    return redirect("/")

@app.route('/Speed', methods=['POST'])
def set_speed():
    speed = request.form.get("speed", "10")
    with open(SPEED_FILE, "w") as f:
        f.write(speed)
    return redirect("/")

@app.route('/RunProgram<int:num>')
def run_program(num: int):
    do_advance = num in (1, 2, 3, 4, 30, 31)
    threading.Thread(target=run_hid_script, args=(num, do_advance), daemon=True).start()
    return redirect("/")

@app.route('/status')
def get_status():
    try:
        with open(STATUS_FILE, "r") as f:
            status = f.read().strip()
    except:
        status = "woff"

    try:
        with open(CURRENT_INDEX_FILE, "r") as f:
            index = int(f.read().strip())
    except:
        index = 0

    try:
        with open(CREDENTIALS_FILE, "r") as f:
            lines = [line.strip() for line in f if line.strip()]
    except:
        lines = []

    current = lines[index] if index < len(lines) else "END"
    total = len(lines)

    return f"{status}|{current}|{index+1}|{total}"

@app.route('/previous')
def get_previous():
    try:
        with open(CURRENT_INDEX_FILE, "r") as f:
            index = int(f.read().strip())
    except:
        index = 0

    try:
        with open(CREDENTIALS_FILE, "r") as f:
            lines = [line.strip() for line in f if line.strip()]
    except:
        lines = []

    total = len(lines)
    if total == 0 or index == 0:
        previous = "NONE"
    else:
        prev_idx = index - 1 if index <= total else total - 1
        previous = lines[prev_idx]

    return previous, 200, {"Content-Type": "text/plain; charset=utf-8"}

@app.route('/TOTP')
def set_totp_code():
    code = (request.args.get("code") or "").strip()
    if not (len(code) == 6 and code.isdigit()):
        return "invalid code (must be 6 digits)", 400

    with open(TOTP_FILE, "w") as f:
        f.write(code)

    threading.Thread(target=run_hid_script, args=(20, False), daemon=True).start()
    return "ok & run20", 200

# ---------- جدید: API/دانلود «باقی‌مانده» (خام، بدون ماسک) ----------
def _read_index_and_lines():
    """برگشت می‌دهد: index فعلی (0-مبنایی) و لیست خطوط credentials.txt (trim‌شده)."""
    try:
        with open(CURRENT_INDEX_FILE, "r") as f:
            index = int(f.read().strip())
    except:
        index = 0

    try:
        with open(CREDENTIALS_FILE, "r") as f:
            lines = [line.strip() for line in f if line.strip()]
    except:
        lines = []

    return index, lines

@app.route('/remaining')
def api_remaining_raw():
    """
    JSON از خطوط «باقی‌مانده» را برمی‌گرداند (خام، بدون ماسک یا split).
    تعریف «باقی‌مانده»: آیتم‌های بعد از CURRENT (فعلی)، یعنی از index+1 به بعد.
    """
    index, lines = _read_index_and_lines()
    start = min(index + 1, len(lines))  # بعد از آیتم فعلی
    items = lines[start:]               # خام

    return jsonify({
        "items": items,
        "from": start + 1,    # 1-مبنایی برای نمایش انسانی
        "total": len(lines)
    }), 200

@app.route('/download_remaining')
def download_remaining_raw():
    """
    فایل متنی خطوط «باقی‌مانده» را به‌صورت خام (بدون ماسک) دانلود می‌کند.
    پارامتر اختیاری 'from' (۱-مبنایی): اگر داده شود از آن رکورد به بعد می‌بُرد،
    وگرنه «بعد از فعلی» (index+1) لحاظ می‌شود.
    """
    index, lines = _read_index_and_lines()

    # مبنای پیش‌فرض: بعد از فعلی
    start = index + 1

    # اگر کاربر from داد (۱-مبنایی)، تبدیل به 0-مبنایی و نرمال‌سازی
    raw_from = (request.args.get("from") or "").strip()
    if raw_from.isdigit():
        human_from = max(1, int(raw_from))
        start = human_from - 1

    start = max(0, min(start, len(lines)))
    out_lines = lines[start:]  # خام

    text = "\n".join(out_lines)
    return Response(
        text,
        mimetype="text/plain; charset=utf-8",
        headers={"Content-Disposition": "attachment; filename=remaining.txt"}
    )
# --------------------------------------------------------------------

if __name__ == '__main__':
    if not os.path.exists(REPLACE_AT_FILE):
        with open(REPLACE_AT_FILE, "w") as f:
            f.write("@")
    if not os.path.exists(SPEED_FILE):
        with open(SPEED_FILE, "w") as f:
            f.write("10")
    if not os.path.exists(CURRENT_INDEX_FILE):
        with open(CURRENT_INDEX_FILE, "w") as f:
            f.write("0")
    if not os.path.exists(STATUS_FILE):
        with open(STATUS_FILE, "w") as f:
            f.write("woff")
    if not os.path.exists(TOTP_FILE):
        with open(TOTP_FILE, "w") as f:
            f.write("")

    app.run(host='0.0.0.0', port=80)
