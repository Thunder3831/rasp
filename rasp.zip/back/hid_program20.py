import time
import sys
from pathlib import Path

hid_path = "/dev/hidg0"

# بررسی حداقل تعداد آرگومان‌ها
if len(sys.argv) < 3:
    print("Usage: python3 script.py <email> <password> [replace_at] [delay_factor]")
    sys.exit(1)

mail = sys.argv[1]
password = sys.argv[2]
replace_at_arg = sys.argv[3] if len(sys.argv) > 3 else "@"

# اگر مقدار سوم "n" بود، فرض کن منظورش دابل‌کوتیشن بوده
if replace_at_arg == "n":
    replace_at = '"'
else:
    replace_at = replace_at_arg

# جایگزینی @
mail = mail.replace('@', replace_at)
password = password.replace('@', replace_at)

# ضریب تأخیر از آرگومان پنجم
delay_factor = float(sys.argv[4]) / 10 if len(sys.argv) > 4 else 1.0

# مسیر فایل TOTP (نسبت به دایرکتوری اجرای اسکریپت)
TOTP_FILE = "totp_code.txt"  # در صورت نیاز: TOTP_FILE = str(Path(__file__).resolve().parent / "totp_code.txt")

key_codes = {
    "esc": 0x29,
    "enter": 0x28,
    "left": 0x50,
    "right": 0x4F,
    "down": 0x51,
    "up": 0x52,
    "backspace": 0x2A,
    "tab": 0x2B,
    "space": 0x2C,
}

def press_key(hid_file, key_code, shift=False):
    modifiers = 0x02 if shift else 0x00
    report = bytearray(8)
    report[0] = modifiers
    report[2] = key_code
    hid_file.write(report)
    hid_file.flush()
    time.sleep(0.05)  # 50ms نگه داشتن کلید
    hid_file.write(bytearray(8))  # رها کردن کلید
    hid_file.flush()
    time.sleep(0.01)

def char_to_keycode(ch):
    char_map = {
        'a': (0x04, False), 'b': (0x05, False), 'c': (0x06, False), 'd': (0x07, False),
        'e': (0x08, False), 'f': (0x09, False), 'g': (0x0A, False), 'h': (0x0B, False),
        'i': (0x0C, False), 'j': (0x0D, False), 'k': (0x0E, False), 'l': (0x0F, False),
        'm': (0x10, False), 'n': (0x11, False), 'o': (0x12, False), 'p': (0x13, False),
        'q': (0x14, False), 'r': (0x15, False), 's': (0x16, False), 't': (0x17, False),
        'u': (0x18, False), 'v': (0x19, False), 'w': (0x1A, False), 'x': (0x1B, False),
        'y': (0x1C, False), 'z': (0x1D, False),

        'A': (0x04, True), 'B': (0x05, True), 'C': (0x06, True), 'D': (0x07, True),
        'E': (0x08, True), 'F': (0x09, True), 'G': (0x0A, True), 'H': (0x0B, True),
        'I': (0x0C, True), 'J': (0x0D, True), 'K': (0x0E, True), 'L': (0x0F, True),
        'M': (0x10, True), 'N': (0x11, True), 'O': (0x12, True), 'P': (0x13, True),
        'Q': (0x14, True), 'R': (0x15, True), 'S': (0x16, True), 'T': (0x17, True),
        'U': (0x18, True), 'V': (0x19, True), 'W': (0x1A, True), 'X': (0x1B, True),
        'Y': (0x1C, True), 'Z': (0x1D, True),

        '1': (0x1E, False), '2': (0x1F, False), '3': (0x20, False), '4': (0x21, False),
        '5': (0x22, False), '6': (0x23, False), '7': (0x24, False), '8': (0x25, False),
        '9': (0x26, False), '0': (0x27, False),

        '!': (0x1E, True), '@': (0x1F, True), '#': (0x20, True), '$': (0x21, True),
        '%': (0x22, True), '^': (0x23, True), '&': (0x24, True), '*': (0x25, True),
        '(': (0x26, True), ')': (0x27, True),

        '-': (0x2D, False), '_': (0x2D, True),
        '=': (0x2E, False), '+': (0x2E, True),
        '[': (0x2F, False), '{': (0x2F, True),
        ']': (0x30, False), '}': (0x30, True),
        '\\':(0x31, False), '|': (0x31, True),
        ';': (0x33, False), ':': (0x33, True),
        '\'':(0x34, False), '"': (0x34, True),
        '`': (0x35, False), '~': (0x35, True),
        ',': (0x36, False), '<': (0x36, True),
        '.': (0x37, False), '>': (0x37, True),
        '/': (0x38, False), '?': (0x38, True),
        ' ': (0x2C, False),
    }
    return char_map.get(ch, (0x2C, False))

def type_string(hid_file, s):
    for ch in s:
        key_code, shift = char_to_keycode(ch)
        press_key(hid_file, key_code, shift)
        time.sleep(0.05)

def read_totp():
    """خواندن کد از فایل و حذف فاصله‌ها/خط‌جدید."""
    try:
        with open(TOTP_FILE, "r") as f:
            return f.read().strip()
    except FileNotFoundError:
        return ""
    except Exception:
        return ""

def clear_totp():
    """خالی کردن فایل TOTP بعد از استفاده."""
    try:
        with open(TOTP_FILE, "w") as f:
            f.write("")
    except Exception:
        pass

def main():
    # می‌تونی همین placeholder رو نگه داری؛ هندل می‌شه:
    sequence = [
        "up",200,
        "up",200,
        "enter", 700,
        "backspace", 200,"backspace", 200,"backspace", 200,"backspace", 200,"backspace", 200,"backspace", 200,
        "codeFrom_totp_code.txt",300,  # یا "totp" / "TOTP"
	"enter", 300,
	"down", 300,
	"enter",5000

    ]

    with open(hid_path, "wb") as hid_file:
        for cmd in sequence:
            if isinstance(cmd, int):
                time.sleep((cmd * delay_factor) / 1000)  # ← ضریب به تاخیر اعمال می‌شود
            elif isinstance(cmd, str) and cmd.lower() in key_codes:
                press_key(hid_file, key_codes[cmd.lower()])
            elif cmd == "mail":
                type_string(hid_file, mail)
            elif cmd == "pass":
                type_string(hid_file, password)
            elif isinstance(cmd, str) and cmd in ("codeFrom_totp_code.txt", "totp", "TOTP"):
                code = read_totp()
                if code:
                    type_string(hid_file, code)
                clear_totp()
            else:
                print("Unknown command:", cmd)

if __name__ == "__main__":
    main()
